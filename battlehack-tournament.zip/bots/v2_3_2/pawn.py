import random
from resources import dlog

lifespan = 0
isDefendingLeft = False
isDefendingRight = False

class Space():
    def __init__(self):
        self.INVALID = -999
        self.BLOCKED = 0
        self.UNBLOCKED = 1

Space = Space()

# Move value manipulation functions
def noBlock(blocked):
    if blocked > -999: return 0
    else:              return -999
def bigPriority(priority):
    if priority >= 0.5:
        return 50 + priority
    else:
        return priority

def moveValueFunction(safety, blocked, priority, lifespan):
    value = 2 * safety
    if lifespan < 35:
        value += blocked + priority
    else:
        value += blocked + bigPriority(priority)
    return value

def checkSpace(r, c, boardSize):
    # check space, except doesn't hit you with game errors
    if r < 0 or c < 0 or c >= boardSize or r >= boardSize:
        return False
    try:
        return check_space(r, c)
    except:
        return False

def checkDanger(forward, team, oppTeam, boardSize, row, col):
    safety = 0
    if checkSpace(row + forward, col + 1, boardSize) == oppTeam:
        safety -= 1
    if checkSpace(row + forward, col - 1, boardSize) == oppTeam:
        safety -= 1
    if checkSpace(row - forward, col + 1, boardSize) == team:
        safety += 1
    if checkSpace(row - forward, col - 1, boardSize) == team:
        safety += 1
    return safety

def checkDefending(forward, team, oppTeam, row, col, boardSize):
    global isDefendingLeft
    global isDefendingRight
    isDefendingLeft = False
    isDefendingRight = False
    if checkSpace(row + forward, col - 1, boardSize) == team:
        if checkDanger(forward, team, oppTeam, boardSize, row + forward, col - 1) < 1:
            isDefendingLeft = True
    if checkSpace(row + forward, col + 1, boardSize) == team:
        if checkDanger(forward, team, oppTeam, boardSize, row + forward, col + 1) < 1:
            isDefendingRight = True

def turnPawn(team, oppTeam, boardSize):
    global lifespan
    global isDefendingLeft
    global isDefendingRight

    lifespan += 1

    row, col = get_location()

    canSeeOpp = False # whether we can see an enemy in front of us
    if team == Team.WHITE:
        forward = 1
        for pawn in sense():
            if pawn[0] > row and pawn[2] == oppTeam:
                canSeeOpp = True
                break
    else:
        forward = -1
        for pawn in sense():
            if pawn[0] < row and pawn[2] == oppTeam:
                canSeeOpp = True
                break

    # If we are at the end of the board, don't move
    if row + forward > boardSize or row + forward < 0:
        return None

    # if an enemy is not visible, move forward whenever possible
    if not canSeeOpp:
        if not checkSpace(row + forward, col, boardSize):
            move_forward()
        return None

    # If we are defending an ally that is in danger if we move, keep defending
    checkDefending(forward, team, oppTeam, row, col, boardSize)
    if isDefendingLeft or isDefendingRight:
        return None

    # If we were defending a pawn and there is an enemy there now, capture it
    if isDefendingLeft and checkSpace(row + forward, col - 1, boardSize) == oppTeam:
        hasCaptured = True
        capture(row + forward, col - 1)
    if isDefendingRight and checkSpace(row + forward, col + 1, boardSize) == oppTeam:
        hasCaptured = True
        capture(row + forward, col + 1)

    # Assign a value for how good each move is
    moveValue  = { 'capLeft': 0, 'capRight': 0, 'forward': 0, 'stay': 0 }
    moveSafety = { 'capLeft': 0, 'capRight': 0, 'forward': 0, 'stay': 0 }
    moveBlocked = {
        'capLeft':  Space.INVALID,
        'capRight': Space.INVALID,
        'forward':  Space.INVALID,
        'stay':     Space.UNBLOCKED
    }
    # A basic move priority dictionary, used to break ties between
    #    equally safe and unblocked moves
    movePriority = {
        'capLeft': 0.75, 'capRight': 0.5,
        'forward': 0.25, 'stay': 0
    }

    # Check the safety value of each potential move
    # Calculated by how many enemy units are attacking the space minus
    #     how many ally units are defending the space
    moveSafety['capLeft']  = checkDanger(forward, team, oppTeam, boardSize, row + forward, col - 1) - 1
    moveSafety['forward']  = checkDanger(forward, team, oppTeam, boardSize, row + forward, col)
    moveSafety['capRight'] = checkDanger(forward, team, oppTeam, boardSize, row + forward, col + 1) - 1
    moveSafety['stay']     = checkDanger(forward, team, oppTeam, boardSize, row, col)

    # Check how possibility the move is
    #   0 => Impossible
    #   1 => Possible, but will be blocked if make this move
    #   2 => Possible and unblocked if made
    if checkSpace(row + forward, col - 1, boardSize) == oppTeam:
        if not checkSpace(row + 2 * forward, col - 1, boardSize):
            moveBlocked['capLeft'] = Space.UNBLOCKED
        else:
            moveBlocked['capLeft'] = Space.BLOCKED
    if checkSpace(row + forward, col + 1, boardSize) == oppTeam:
        if not checkSpace(row + 2 * forward, col + 1, boardSize):
            moveBlocked['capRight'] = Space.UNBLOCKED
        else:
            moveBlocked['capRight'] = Space.BLOCKED
    if not checkSpace(row + forward, col, boardSize):
        if not checkSpace(row + 2 * forward, col, boardSize):
            moveBlocked['forward'] = Space.UNBLOCKED
        else:
            moveBlocked['forward'] = Space.BLOCKED
    else:
        moveBlocked['stay'] = Space.BLOCKED

    for k in moveValue:
        moveValue[k] = moveValueFunction(moveSafety[k], moveBlocked[k], movePriority[k], lifespan)

    move = 'stay' # The move we choose to use
    max = -999
    # Prioritize the most valuable move
    for k in moveValue:
        if moveValue[k] > max:
            max = moveValue[k]
            move = k

    if move == 'capLeft':
        capture(row + forward, col - 1)
    elif move == 'capRight':
        capture(row + forward, col + 1)
    elif move == 'forward':
        move_forward()
    return None
