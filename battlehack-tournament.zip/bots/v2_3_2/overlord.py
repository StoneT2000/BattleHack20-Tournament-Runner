import random
import math
from resources import dlog

turn = 0

def columnPriority(col, teamCount, oppTeamCount):
    value = (abs(col - 7.5) - 0.5) / 2 + 1
    if oppTeamCount < 6:
        value += 6 - oppTeamCount
    else:
        value += oppTeamCount / 1.5
    value += teamCount / 4
    return value

def startSpawn(row, oppTeam, boardSize, teamCount, oppTeamCount, gameBoard):
    prioritySpawning = [0 for _ in range(boardSize)]
    for col in range(boardSize):
        if oppTeamCount[col] > 0:
            if col > 0 and teamCount[col - 1] == 0:
                prioritySpawning[col - 1] = prioritySpawning[col - 1] + 1
                if col < boardSize - 1 and teamCount[col + 1] == 0:
                    prioritySpawning[col - 1] = prioritySpawning[col - 1] + 1
            elif col == 0 and teamCount[col + 1] == 0:
                prioritySpawning[col + 1] = prioritySpawning[col + 1] + 1
            if col < boardSize - 1 and teamCount[col + 1] == 0:
                prioritySpawning[col + 1] = prioritySpawning[col + 1] + 1
                if col > 0 and teamCount[col - 1] == 0:
                    prioritySpawning[col + 1] = prioritySpawning[col + 1] + 1
            elif col == boardSize - 1 and teamCount[col - 1] == 0:
                prioritySpawning[col - 1] = prioritySpawning[col - 1] + 1
    #dlog(str(prioritySpawning))
    # Find the list of maximum priority columns
    possibleList = []
    max = -1
    for i, val in enumerate(prioritySpawning):
        if val > max:
            possibleList = [ i ]
            max = val
        elif val == max:
            possibleList.append(i)
    # Find the nearest enemy in the max priority columns
    min = boardSize
    minCol = -1
    for col in possibleList:
        nearestEnemy = boardSize
        for r in range(boardSize):
            dist = abs(r - row)
            if col > 0 and gameBoard[r][col - 1] == oppTeam and dist < nearestEnemy:
                nearestEnemy = dist
            if col < boardSize - 1 and gameBoard[r][col + 1] == oppTeam and dist < nearestEnemy:
                nearestEnemy = dist
        if nearestEnemy < min:
            min = nearestEnemy
            minCol = col
    if minCol >= 0:
        spawn(row, minCol)
        return True
    return False

def emergencySpawn(forward, row, oppTeam, boardSize, gameBoard):
    dangerList = []
    for i in range(boardSize):
        if gameBoard[row + forward][i] == oppTeam and gameBoard[row][i] == None:
            dangerList.append(i)
    if len(dangerList) > 0:
        for v in dangerList:
            if v > 0 and gameBoard[row + forward][v - 1] == oppTeam:
                if gameBoard[row][v - 1] == None:
                    spawn(row, v)
                    return None
                else:
                    dangerList.remove(v)
            if v < boardSize - 1 and gameBoard[row + forward][v + 1] == oppTeam:
                if gameBoard[row][v + 1] == None:
                    spawn(row, v)
                    return None
                else:
                    dangerList.remove(v)
        if len(dangerList) > 0:
            spawn(row, dangerList[0])
            return True
    return False

def turnOverlord(team, oppTeam, boardSize):
    global turn
    turn += 1

    if team == Team.WHITE:
        forward = 1
        row = 0
        oppRow = boardSize - 1
    else:
        forward = -1
        row = boardSize - 1
        oppRow = 0

    gameBoard = get_board()

    # Check if in danger
    if emergencySpawn(forward, row, oppTeam, boardSize, gameBoard):
        return None

    # Count how many enemies and allies in each collumn
    teamCount = []
    oppTeamCount = []
    for col in range(boardSize):
        teamCount.append(0)
        oppTeamCount.append(0)
        for r in range(boardSize):
            if gameBoard[r][col] == team:
                teamCount[col] = teamCount[col] + 1
            elif gameBoard[r][col] == oppTeam:
                oppTeamCount[col] = oppTeamCount[col] + 1
    if turn < boardSize:
        if startSpawn(row, oppTeam, boardSize, teamCount, oppTeamCount, gameBoard):
            return None

    probList = []
    for col in range(boardSize):
        probList.append(0)
        if gameBoard[oppRow][col] == team:
            #if teamCount[col] > 2:
            #    probList[col] = 1
            #    continue
            if col < 0 or gameBoard[oppRow][col - 1] == team:
                if (col >= boardSize - 1) or gameBoard[oppRow][col + 1] == team:
                    probList[col] = 1
                    continue
            probList[col] = 1
        if col > 0 and gameBoard[row + forward][col - 1] == oppTeam:
            continue
        if (col < boardSize - 1) and gameBoard[row + forward][col + 1] == oppTeam:
            continue
        if gameBoard[row][col] == None:
            oppTeamVal = oppTeamCount[col]
            if col == 0:
                oppTeamVal += oppTeamCount[col + 1]
            elif col == boardSize - 1:
                oppTeamVal += oppTeamCount[col - 1]
            else:
                oppTeamVal += (oppTeamCount[col + 1] + oppTeamCount[col - 1]) / 2
            probList[col] = columnPriority(col, teamCount[col], oppTeamVal)

    possibleList = []
    max = 1
    for i, val in enumerate(probList):
        if val > max:
            possibleList = [ i ]
            max = val
        elif val == max:
            possibleList.append(i)

    if len(possibleList) > 0:
        rand = random.randint(0, len(possibleList) - 1)
        spawn(row, possibleList[rand])
    return None
