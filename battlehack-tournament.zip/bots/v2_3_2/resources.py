DEBUG = 1
def dlog(str):
    if DEBUG > 0:
        log(str)

def any(s):
    for v in s:
        if v:
            return True
    return False
