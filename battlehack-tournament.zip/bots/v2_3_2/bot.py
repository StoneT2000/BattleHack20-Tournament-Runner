import random
from resources import dlog
from overlord import turnOverlord
from pawn import turnPawn

def turn():
    boardSize = get_board_size()
    team = get_team()
    oppTeam = Team.WHITE if team == Team.BLACK else Team.BLACK
    type = get_type()
    if type == RobotType.OVERLORD:
        turnOverlord(team, oppTeam, boardSize)
    else:
        turnPawn(team, oppTeam, boardSize)

    bytecode = get_bytecode()
    dlog('Done! Bytecode left: ' + str(bytecode))
